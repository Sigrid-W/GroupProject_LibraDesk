﻿using LibraryMaui.Services;

namespace LibraryMaui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();

        // Initialize SQLite native bits (prevents early crash)
        SQLitePCL.Batteries_V2.Init();   // <-- add this line

        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-SemiBold.ttf", "OpenSansSemiBold");
            });

        builder.Services.AddSingleton<LibraryDatabase>();

        return builder.Build();
    }
}
