﻿using SQLite;

namespace LibraryMaui.Models;

public class Publisher
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [NotNull, Indexed(Unique = true)]
    public string Name { get; set; } = string.Empty;
}
