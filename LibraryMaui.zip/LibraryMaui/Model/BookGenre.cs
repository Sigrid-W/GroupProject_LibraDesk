﻿using SQLite;

namespace LibraryMaui.Models;

// Join table: Book (many) <-> (many) Genre
public class BookGenre
{
    [Indexed("IX_BookGenre_BookId_GenreId", 1, Unique = true)]
    public int BookId { get; set; }

    [Indexed("IX_BookGenre_BookId_GenreId", 2, Unique = true)]
    public int GenreId { get; set; }
}
