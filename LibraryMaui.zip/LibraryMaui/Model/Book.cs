﻿using SQLite;

namespace LibraryMaui.Models;

public class Book
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [NotNull]
    public string Title { get; set; } = string.Empty;

    [Indexed] public int PublisherId { get; set; }

    public int? PublishedYear { get; set; }

    [NotNull] public decimal Price { get; set; } = 0m;
}
