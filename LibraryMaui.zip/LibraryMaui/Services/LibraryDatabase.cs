﻿using System.IO;
using SQLite;
using LibraryMaui.Models;

namespace LibraryMaui.Services;

public class LibraryDatabase
{
    private readonly string _dbPath;
    private SQLiteAsyncConnection _db = default!;
    private bool _initialized;

    public LibraryDatabase()
    {
        _dbPath = Path.Combine(FileSystem.AppDataDirectory, "library.db");
    }

    private async Task EnsureCreatedAsync()
    {
        if (_initialized) return;

        _db = new SQLiteAsyncConnection(_dbPath);
        await _db.CreateTableAsync<Publisher>();
        await _db.CreateTableAsync<Genre>();
        await _db.CreateTableAsync<Book>();
        await _db.CreateTableAsync<BookGenre>();

        await SeedAsync();
        _initialized = true;
    }

    private async Task SeedAsync()
    {
        if (await _db.Table<Publisher>().CountAsync() > 0) return;

        var pubs = new[] { new Publisher { Name = "Penguin" }, new Publisher { Name = "HarperCollins" } };
        await _db.InsertAllAsync(pubs);

        var genres = new[] { new Genre { Name = "Fiction" }, new Genre { Name = "Sci‑Fi" }, new Genre { Name = "History" } };
        await _db.InsertAllAsync(genres);

        var books = new[]
        {
            new Book { Title = "Dune", PublisherId = pubs[1].Id, PublishedYear = 1965, Price = 19.99m },
            new Book { Title = "The Old Man and the Sea", PublisherId = pubs[0].Id, PublishedYear = 1952, Price = 9.99m }
        };
        await _db.InsertAllAsync(books);

        var links = new[]
        {
            new BookGenre { BookId = books[0].Id, GenreId = genres[1].Id }, // Dune -> Sci‑Fi
            new BookGenre { BookId = books[1].Id, GenreId = genres[0].Id }  // Old Man -> Fiction
        };
        await _db.InsertAllAsync(links);
    }

    // -------- Publishers --------
    public async Task<List<Publisher>> GetPublishersAsync()
    {
        await EnsureCreatedAsync();
        return await _db.Table<Publisher>().OrderBy(p => p.Name).ToListAsync();
    }

    public async Task SavePublisherAsync(Publisher p)
    {
        await EnsureCreatedAsync();
        if (p.Id == 0) await _db.InsertAsync(p); else await _db.UpdateAsync(p);
    }

    public async Task DeletePublisherAsync(Publisher p)
    {
        await EnsureCreatedAsync();
        var hasBooks = await _db.Table<Book>().Where(b => b.PublisherId == p.Id).CountAsync() > 0;
        if (hasBooks) throw new InvalidOperationException("Cannot delete: publisher has books.");
        await _db.DeleteAsync(p);
    }

    // -------- Genres --------
    public async Task<List<Genre>> GetGenresAsync()
    {
        await EnsureCreatedAsync();
        return await _db.Table<Genre>().OrderBy(g => g.Name).ToListAsync();
    }

    public async Task SaveGenreAsync(Genre g)
    {
        await EnsureCreatedAsync();
        if (g.Id == 0) await _db.InsertAsync(g); else await _db.UpdateAsync(g);
    }

    public async Task DeleteGenreAsync(Genre g)
    {
        await EnsureCreatedAsync();
        await _db.Table<BookGenre>().DeleteAsync(bg => bg.GenreId == g.Id);
        await _db.DeleteAsync(g);
    }

    // -------- Books --------
    public async Task<List<Book>> GetBooksAsync()
    {
        await EnsureCreatedAsync();
        return await _db.Table<Book>().OrderBy(b => b.Title).ToListAsync();
    }

    public async Task SaveBookAsync(Book b, IEnumerable<int>? genreIds = null)
    {
        await EnsureCreatedAsync();
        if (b.Id == 0) await _db.InsertAsync(b); else await _db.UpdateAsync(b);

        if (genreIds != null)
        {
            await _db.Table<BookGenre>().DeleteAsync(x => x.BookId == b.Id);
            var links = genreIds.Distinct().Select(id => new BookGenre { BookId = b.Id, GenreId = id });
            await _db.InsertAllAsync(links);
        }
    }

    public async Task DeleteBookAsync(Book b)
    {
        await EnsureCreatedAsync();
        await _db.Table<BookGenre>().DeleteAsync(x => x.BookId == b.Id);
        await _db.DeleteAsync(b);
    }

    public async Task<List<int>> GetGenreIdsForBookAsync(int bookId)
    {
        await EnsureCreatedAsync();
        return (await _db.Table<BookGenre>().Where(x => x.BookId == bookId).ToListAsync())
            .Select(x => x.GenreId).ToList();
    }
}
